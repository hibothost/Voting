from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_socketio import SocketIO
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import os
import random
import smtplib
from email.mime.text import MIMEText

app = Flask(__name__)
app.secret_key = 'your-secret-key'
socketio = SocketIO(app, async_mode='threading')

UPLOAD_FOLDER = 'static/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Gmail SMTP configuration (replace with your Gmail app password)
GMAIL_USER = 'sharifsentongo5@gmail.com'  # Replace with your Gmail address
GMAIL_PASSWORD = 'xxqn vxga cmmk jrep'  # Replace with your Gmail app password

def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        student_id TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        is_admin BOOLEAN DEFAULT 0
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS candidates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        position TEXT NOT NULL,
        description TEXT,
        vote_count INTEGER DEFAULT 0,
        image_path TEXT,
        category_id INTEGER,
        FOREIGN KEY (category_id) REFERENCES categories(id)
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS votes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (candidate_id) REFERENCES candidates(id)
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS user_category_votes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        category_id INTEGER,
        candidate_id INTEGER,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (category_id) REFERENCES categories(id),
        FOREIGN KEY (candidate_id) REFERENCES candidates(id),
        UNIQUE (user_id, category_id)
    )''')
    c.execute("SELECT COUNT(*) FROM categories")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO categories (name) VALUES ('Guild President')")
        c.execute("INSERT INTO categories (name) VALUES ('Speaker')")
        c.execute("INSERT INTO categories (name) VALUES ('Treasurer')")
    conn.commit()
    conn.close()

init_db()

def send_verification_code(email, code):
    msg = MIMEText(f"Your verification code is: {code}")
    msg['Subject'] = 'ISLM Voting Verification Code'
    msg['From'] = GMAIL_USER
    msg['To'] = email

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(GMAIL_USER, GMAIL_PASSWORD)
            server.sendmail(GMAIL_USER, email, msg.as_string())
    except Exception as e:
        flash(f"Failed to send verification code: {str(e)}", 'danger')
        return False
    return True

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        student_id = request.form.get('student_id')
        password = request.form.get('password')
        verification_code = request.form.get('verification_code')
        action = request.form.get('action')  # 'send_code' or 'register'

        print(f"Received POST request with action: {action}, email: {email}, student_id: {student_id}")

        # Validate student ID length if registering
        if action == 'register' and student_id and len(student_id) != 22:
            flash('Student ID must be exactly 22 characters long.', 'danger')
            return render_template('register.html', email=email, student_id=student_id, password=password)

        # Send verification code
        if action == 'send_code' and email:
            code = ''.join([str(random.randint(0, 9)) for _ in range(6)])
            session['verification_code'] = code
            print(f"Generated verification code: {code}")
            if not send_verification_code(email, code):
                return render_template('register.html', email=email, student_id=student_id, password=password)
            flash('A 6-digit verification code has been sent to your email. Please enter it below.', 'success')
            return render_template('register.html', email=email, student_id=student_id, password=password)

        # Verify code and register
        if action == 'register' and verification_code and session.get('verification_code'):
            if verification_code == session.get('verification_code'):
                conn = sqlite3.connect('database.db')
                c = conn.cursor()
                # Check for existing email
                c.execute("SELECT email FROM users WHERE email = ?", (email,))
                if c.fetchone():
                    flash('This email is already registered.', 'danger')
                    conn.close()
                    return render_template('register.html', email=email, student_id=student_id, password=password)
                # Check for existing student ID
                c.execute("SELECT student_id FROM users WHERE student_id = ?", (student_id,))
                if c.fetchone():
                    flash('This student ID is already registered.', 'danger')
                    conn.close()
                    return render_template('register.html', email=email, student_id=student_id, password=password)
                # Proceed with registration
                hashed_password = generate_password_hash(password)
                try:
                    c.execute("INSERT INTO users (email, student_id, password) VALUES (?, ?, ?)",
                              (email, student_id, hashed_password))
                    conn.commit()
                    session.pop('verification_code', None)
                    flash('Registration successful! Please log in.', 'success')
                    conn.close()
                    return redirect(url_for('login'))
                except sqlite3.IntegrityError:
                    flash('An unexpected database error occurred. Please contact support.', 'danger')
                    conn.close()
                    return render_template('register.html', email=email, student_id=student_id, password=password)
            else:
                flash('Invalid verification code. Please try again.', 'danger')
                return render_template('register.html', email=email, student_id=student_id, password=password)
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        student_id = request.form['student_id']
        password = request.form['password']

        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE student_id = ?", (student_id,))
        user = c.fetchone()
        conn.close()

        if user and check_password_hash(user[3], password):
            session['user_id'] = user[0]
            session['is_admin'] = user[4]
            flash('Login successful!', 'success')
            return redirect(url_for('voting_dashboard'))
        else:
            flash('Invalid Student ID or Password.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('is_admin', None)
    flash('Logged out successfully.', 'success')
    return redirect(url_for('login'))

@app.route('/voting_dashboard', methods=['GET', 'POST'])
def voting_dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    # Check if user has voted in all categories
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Get total number of categories
    c.execute("SELECT COUNT(*) FROM categories")
    total_categories = c.fetchone()[0]

    # Get number of categories the user has voted in
    c.execute("SELECT COUNT(DISTINCT category_id) FROM user_category_votes WHERE user_id = ?", (session['user_id'],))
    voted_categories_count = c.fetchone()[0]

    if total_categories > 0 and voted_categories_count >= total_categories:
        flash('You have already voted in all categories.', 'info')
        conn.close()
        return redirect(url_for('results'))

    # Load candidates for voting
    c.execute("SELECT c.id, c.name, c.position, c.image_path, cat.name AS category_name, cat.id AS category_id FROM candidates c JOIN categories cat ON c.category_id = cat.id")
    candidates = c.fetchall()
    conn.close()

    # Group candidates by category
    candidates_by_category = {}
    for candidate in candidates:
        category_name = candidate[4]  # cat.name
        if category_name not in candidates_by_category:
            candidates_by_category[category_name] = []
        candidates_by_category[category_name].append(candidate)

    if request.method == 'POST':
        voted_categories = set()
        has_valid_selection = False
        try:
            for key in request.form:
                if key.startswith('candidate_'):
                    candidate_id = int(key.replace('candidate_', ''))
                    print(f"Processing vote for candidate_id: {candidate_id}")  # Debug log
                    conn = sqlite3.connect('database.db')
                    c = conn.cursor()
                    c.execute("SELECT category_id FROM candidates WHERE id = ?", (candidate_id,))
                    category_id_result = c.fetchone()
                    if category_id_result is None:
                        flash('Invalid candidate selected.', 'danger')
                        conn.close()
                        return redirect(url_for('voting_dashboard'))
                    has_valid_selection = True
                    category_id = category_id_result[0]
                    if category_id not in voted_categories:
                        c.execute("SELECT candidate_id FROM user_category_votes WHERE user_id = ? AND category_id = ?", (session['user_id'], category_id))
                        existing_vote = c.fetchone()
                        if existing_vote:
                            flash('You have already voted in this category.', 'warning')
                            conn.close()
                            return redirect(url_for('results'))
                        c.execute("INSERT INTO user_category_votes (user_id, category_id, candidate_id) VALUES (?, ?, ?)",
                                  (session['user_id'], category_id, candidate_id))
                        c.execute("UPDATE candidates SET vote_count = vote_count + 1 WHERE id = ?", (candidate_id,))
                        voted_categories.add(category_id)
                        conn.commit()
        except Exception as e:
            print(f"Error in voting_dashboard POST: {str(e)}")  # Debug log
            flash(f'An error occurred while voting: {str(e)}', 'danger')
            return redirect(url_for('voting_dashboard'))
        finally:
            conn.close()

        if not has_valid_selection:
            flash('Please select at least one candidate to vote for.', 'danger')
            return redirect(url_for('voting_dashboard'))
        flash('Thank you for your vote!', 'success')
        return redirect(url_for('results'))
    return render_template('voting_dashboard.html', candidates_by_category=candidates_by_category)

@app.route('/candidate_profiles')
def candidate_profiles():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT c.id, c.name, c.position, c.description, c.image_path, cat.name AS category_name FROM candidates c JOIN categories cat ON c.category_id = cat.id")
    candidates = c.fetchall()
    conn.close()

    # Group candidates by category
    candidates_by_category = {}
    for candidate in candidates:
        category_name = candidate[5]  # cat.name
        if category_name not in candidates_by_category:
            candidates_by_category[category_name] = []
        candidates_by_category[category_name].append(candidate)

    return render_template('candidate_profiles.html', candidates_by_category=candidates_by_category)

def get_results():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT c.name, c.position, c.vote_count, cat.name AS category_name, c.image_path FROM candidates c JOIN categories cat ON c.category_id = cat.id")
    candidates = c.fetchall()
    conn.close()

    # Group candidates by category
    results_by_category = {}
    for candidate in candidates:
        category_name = candidate[3]  # cat.name
        if category_name not in results_by_category:
            results_by_category[category_name] = []
        results_by_category[category_name].append(candidate)

    return results_by_category

@app.route('/results')
def results():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('results.html', results_by_category=get_results())

@app.route('/admin_panel', methods=['GET', 'POST'])
def admin_panel():
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Admins only.', 'danger')
        return redirect(url_for('voting_dashboard'))

    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        position = request.form['position']
        description = request.form['description']
        category_id = request.form['category_id']
        image = request.files.get('image')

        image_path = None
        if image:
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image.filename)
            image.save(image_path)
            image_path = f'uploads/{image.filename}'

        c.execute("INSERT INTO candidates (name, position, description, image_path, category_id) VALUES (?, ?, ?, ?, ?)",
                  (name, position, description, image_path, category_id))
        conn.commit()
        flash('Candidate added successfully!', 'success')

    c.execute("SELECT id, name FROM categories")
    categories = c.fetchall()
    c.execute("SELECT c.id, c.name, c.position, c.image_path, cat.name AS category_name FROM candidates c JOIN categories cat ON c.category_id = cat.id")
    candidates = c.fetchall()
    conn.close()
    return render_template('admin_panel.html', candidates=candidates, categories=categories)

@app.route('/delete_candidate/<int:candidate_id>', methods=['POST'])
def delete_candidate(candidate_id):
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Admins only.', 'danger')
        return redirect(url_for('voting_dashboard'))

    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("DELETE FROM votes WHERE candidate_id = ?", (candidate_id,))
    c.execute("SELECT image_path FROM candidates WHERE id = ?", (candidate_id,))
    candidate = c.fetchone()
    if candidate and candidate[0]:
        image_path = os.path.join('static', candidate[0])
        if os.path.exists(image_path):
            os.remove(image_path)
    c.execute("DELETE FROM candidates WHERE id = ?", (candidate_id,))
    conn.commit()
    conn.close()
    flash('Candidate deleted successfully!', 'success')
    return redirect(url_for('admin_panel'))

@socketio.on('connect')
def handle_connect():
    emit('update_results', get_results(), broadcast=True)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=80, debug=True)
